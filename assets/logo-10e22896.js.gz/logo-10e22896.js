const t=`<svg width = "64" height="36" id="eJ4zxKkD1v91" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 64 36" shape-rendering="geometricPrecision" text-rendering="geometricPrecision">
<g transform="translate(-8.5-22.359368)">
	<path d="M13.62051,35c.0267-12.35171,9.45873-22.59775,21.82949-24.57144L35.45,35h-21.82949Z"
	transform="translate(0 15.851659)" fill="currentColor" stroke-width="0"/>
	<path d="M13.62051,35c.0267-12.35171,9.45873-22.59775,21.82949-24.57144L35.45,35h-21.82949Z" 
	transform="translate(0 15.895087)" fill="#fff" fill-opacity="0.2" stroke-width="0"/></g>
<g transform="translate(-8.499999-22.359368)">
	<path d="M13.62051,35c.0267-12.35171,9.45873-22.59775,21.82949-24.57144L35.45,35h-21.82949Z" 
	transform="matrix(-1 0 0 1 80.673138 15.851659)" fill="currentColor" stroke-width="0"/>
	<path d="M13.62051,35c.0267-12.35171,9.45873-22.59775,21.82949-24.57144L35.45,35h-21.82949Z" 
	transform="matrix(-1 0 0 1 80.673138 15.851659)" fill="#fff" fill-opacity="0.2" stroke-width="0"/></g>
<rect width="59.446276" fill="currentColor" height="6.813779" rx="0" ry="0" transform="matrix(1 0 0 0.513665 2.276862 30.492293)" stroke-width="0"/>
<rect width="39.119365" fill="currentColor" height="7.162988" rx="0" ry="0" transform="matrix(.155933 0 0 4.465257 28.95 2.007708)" stroke-width="0"/></svg>
`;export{t as l};
